output "resource_group_name" {
  description = "Resource group created by the networking module."
  value       = module.networking.resource_group_name
}

output "location" {
  description = "Azure region used by this deployment."
  value       = module.networking.location
}

output "load_balancer_public_ip" {
  description = "Public IP address of the Azure Load Balancer."
  value       = module.load_balancer.public_ip_address
}

output "load_balancer_fqdn" {
  description = "DNS label is not configured in this example; use the public IP output."
  value       = null
}

output "vm_details" {
  description = "Virtual machine details, keyed by instance map key."
  value       = module.compute.vm_details
}

locals {
  name_prefix = "${var.project_name}-${var.environment}"

  project_tags = {
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "Terraform"
  }
}

module "networking" {
  source = "./modules/networking"

  name_prefix                = local.name_prefix
  resource_group_name        = var.resource_group_name
  location                   = var.location
  vnet_name                  = var.vnet_name
  vnet_address_space         = var.vnet_address_space
  subnet_name                = var.subnet_name
  subnet_address_prefixes    = var.subnet_address_prefixes
  ssh_source_address_prefix  = var.ssh_source_address_prefix
  tags                       = local.project_tags
}

module "compute" {
  source = "./modules/compute"

  name_prefix          = local.name_prefix
  resource_group_name  = module.networking.resource_group_name
  location             = module.networking.location
  subnet_id            = module.networking.subnet_id
  instance             = var.instance
  admin_username       = var.admin_username
  ssh_public_key_path  = var.ssh_public_key_path
  tags                 = local.project_tags
}

module "load_balancer" {
  source = "./modules/load-balancer"

  name_prefix                  = local.name_prefix
  resource_group_name          = module.networking.resource_group_name
  location                     = module.networking.location
  nic_ids                      = module.compute.nic_ids
  nic_ip_configuration_names   = module.compute.nic_ip_configuration_names
  frontend_port                = var.lb_frontend_port
  backend_port                 = var.lb_backend_port
  tags                         = local.project_tags
}

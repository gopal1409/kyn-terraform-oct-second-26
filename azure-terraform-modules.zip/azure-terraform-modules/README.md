# Azure Terraform Modules: Networking, Compute, and Load Balancer

This project refactors the supplied single-root Azure configuration into reusable local modules:

- `modules/networking`: Resource Group, VNet, subnet, NSG, inbound rules
- `modules/compute`: NICs and multiple Linux VMs using `for_each`
- `modules/load-balancer`: Standard public Load Balancer, frontend Public IP, backend pool, probe, rule, and NIC associations
- Root module: wires modules together and selects dev/test/prod values

## 1. Prerequisites

- Terraform CLI installed (`terraform version`)
- Azure CLI installed (`az version`)
- Azure subscription and permission to create resource groups, networking, VMs, Public IPs, and load balancers
- SSH public key available locally
- The backend Storage Account and Blob container already created if using the configured remote backend

## 2. Repository layout

```text
azure-terraform-modules/
├── backend.tf
├── versions.tf
├── provider.tf
├── variables.tf
├── main.tf
├── outputs.tf
├── dev.tfvars
├── test.tfvars
├── prod.tfvars
├── .gitignore
├── README.md
└── modules/
    ├── networking/
    │   ├── main.tf
    │   ├── variables.tf
    │   └── outputs.tf
    ├── compute/
    │   ├── main.tf
    │   ├── variables.tf
    │   └── outputs.tf
    └── load-balancer/
        ├── main.tf
        ├── variables.tf
        └── outputs.tf
```

## 3. Important: configure remote state

`backend.tf` contains the storage account details supplied in the original example. Confirm they are correct for your subscription before running `terraform init`.

The AzureRM backend's Storage Account and container must exist before initialization. For Azure AD / Entra ID authentication, the identity running Terraform needs appropriate Blob data permissions, commonly `Storage Blob Data Contributor` scoped to the state container.

To avoid state collisions, each environment has a distinct backend key. Before first use, change `key` in `backend.tf` to the environment-specific key you intend to use, for example `sap-dev.tfstate`. For a team managing all three environments, use separate root working directories / HCP Terraform workspaces or reconfigure the backend key and migrate state carefully between environments. Do not run dev, test, and prod against the same state key.

For HCP Terraform, normally configure the workspace's remote execution and workspace variables according to your HCP Terraform workflow; don't assume a local Azure Blob backend and HCP Terraform workspace state are interchangeable. Use one state-management approach per root configuration.

## 4. Authentication

### Local workstation with Azure CLI

```bash
az login
az account set --subscription "<SUBSCRIPTION_ID>"
```

`provider.tf` uses AzureRM provider authentication through the Azure CLI identity by default. Ensure that identity has permissions on the target subscription/resource group and on the backend storage data plane.

### Service Principal via environment variables

Set these in your shell or CI/CD secret store (do not commit secrets):

PowerShell:
```powershell
$env:ARM_CLIENT_ID = "<APP_CLIENT_ID>"
$env:ARM_CLIENT_SECRET = "<CLIENT_SECRET>"
$env:ARM_TENANT_ID = "<TENANT_ID>"
$env:ARM_SUBSCRIPTION_ID = "<SUBSCRIPTION_ID>"
```

Bash:
```bash
export ARM_CLIENT_ID="<APP_CLIENT_ID>"
export ARM_CLIENT_SECRET="<CLIENT_SECRET>"
export ARM_TENANT_ID="<TENANT_ID>"
export ARM_SUBSCRIPTION_ID="<SUBSCRIPTION_ID>"
```

For the AzureRM backend, this example enables Entra ID auth in `backend.tf`; the identity also needs Blob data permissions. For production HCP Terraform, consider workload identity federation (OIDC) instead of long-lived client secrets.

## 5. SSH public key

The root variable `ssh_public_key_path` points to `~/.ssh/id_rsa.pub` by default. Change it in the `.tfvars` file or pass it with `-var` if your public key is stored elsewhere.

Example to create a key if you do not have one:

```bash
ssh-keygen -t ed25519 -f ~/.ssh/azure_terraform
```

Then set `ssh_public_key_path` to the generated `.pub` file. Never upload the private key.

## 6. Deploy

From the repository root:

```bash
terraform init
terraform fmt -recursive
terraform validate
terraform plan -var-file=dev.tfvars -out=dev.tfplan
terraform apply dev.tfplan
terraform output
```

For test and prod, use the corresponding variable file, but first ensure the backend key is isolated for that environment. A saved plan file can contain sensitive data; do not commit `.tfplan` files.

To destroy a specific environment, select its correct backend/workspace/state first, then run:

```bash
terraform plan -destroy -var-file=dev.tfvars
terraform destroy -var-file=dev.tfvars
```

Review the plan carefully before confirming.

## 7. Upload to GitHub

1. Create a new empty GitHub repository, e.g. `azure-terraform-modules`. Do not initialize it with a README if you already have this README locally.
2. Extract this ZIP.
3. Open a terminal in the extracted `azure-terraform-modules` directory.
4. Initialize Git and commit:

```bash
git init
git add .
git status
git commit -m "Add reusable Azure Terraform modules"
git branch -M main
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/azure-terraform-modules.git
git push -u origin main
```

5. Replace `<YOUR_GITHUB_USERNAME>` with your GitHub username. Authenticate with GitHub when prompted. Do not put a GitHub token in the remote URL.

## 8. Call the modules from a different workstation

On another workstation, install Terraform and Azure CLI, clone the repository, and authenticate:

```bash
git clone https://github.com/<YOUR_GITHUB_USERNAME>/azure-terraform-modules.git
cd azure-terraform-modules
az login
az account set --subscription "<SUBSCRIPTION_ID>"
terraform init
terraform validate
terraform plan -var-file=dev.tfvars
terraform apply -var-file=dev.tfvars
```

You do not need to copy module files separately: Git clone downloads them with the root configuration. Both workstations must use the same intended backend key/state to collaborate on the same environment. Never use a different state key unintentionally, as Terraform may try to create duplicate resources.

## 9. Consume modules from a separate Terraform project

A different root project can reference modules hosted in GitHub:

```hcl
module "networking" {
  source = "git::https://github.com/<YOUR_GITHUB_USERNAME>/azure-terraform-modules.git//modules/networking?ref=v1.0.0"

  # Provide required variables as documented in modules/networking/variables.tf.
}
```

The example above shows the source syntax only. This repository's root configuration wires all three modules together. To reuse the complete stack, clone this repository and use its root configuration. To consume a module individually, pass all its required inputs from the calling root module.

Create and push a version tag after testing module changes:

```bash
git tag v1.0.0
git push origin v1.0.0
```

Pin Git module sources to a tag or commit SHA in shared/prod configurations.

## 10. Notes about this example

- VM names, VM sizes, and Availability Zones are driven by `instance` in the environment `.tfvars`.
- Each VM gets its own NIC. The Load Balancer module attaches those NIC IP configurations to its backend pool.
- The Load Balancer uses one shared public IP; backend VMs do not get individual public IPs.
- The NSG example allows SSH, HTTP, and HTTPS. Restrict SSH to a trusted source CIDR before deploying. The example does not add an RDP rule because these are Linux VMs.
- A TCP health probe on port 80 will only pass if an application is listening on port 80 on each VM. The provided cloud-init script installs and starts Nginx.
- Azure VM sizes and Availability Zone support vary by region/subscription. Confirm selected sizes and zones are available in `eastus` before applying.

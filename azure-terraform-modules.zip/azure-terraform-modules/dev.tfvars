project_name    = "sap"
environment     = "dev"
resource_group_name = "gopal_rg"
location        = "eastus"

vnet_name               = "gopal-network"
vnet_address_space      = ["10.0.0.0/16"]
subnet_name             = "web-subnet"
subnet_address_prefixes = ["10.0.1.0/24"]

# Replace with your own public IP /32 before applying.
ssh_source_address_prefix = "203.0.113.10/32"
ssh_public_key_path       = "~/.ssh/azure_terraform.pub"

instance = {
  vm1 = {
    size              = "Standard_F2"
    availability_zone = "1"
  }
  vm2 = {
    size              = "Standard_B1s"
    availability_zone = "2"
  }
}

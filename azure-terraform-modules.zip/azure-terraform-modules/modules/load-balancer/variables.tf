variable "name_prefix" {
  type        = string
  description = "Prefix used for resource names."
}

variable "resource_group_name" {
  type        = string
  description = "Resource group containing the load balancer."
}

variable "location" {
  type        = string
  description = "Azure region."
}

variable "nic_ids" {
  type        = map(string)
  description = "NIC IDs keyed by VM instance key."
}

variable "nic_ip_configuration_names" {
  type        = map(string)
  description = "NIC IP configuration names keyed by VM instance key."
}

variable "frontend_port" {
  type        = number
  description = "Load balancer frontend port."
}

variable "backend_port" {
  type        = number
  description = "Backend VM port."
}

variable "tags" {
  type        = map(string)
  description = "Tags to apply to resources."
}

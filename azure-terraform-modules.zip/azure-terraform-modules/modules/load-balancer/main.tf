resource "azurerm_public_ip" "this" {
  name                = "${var.name_prefix}-lb-public-ip"
  resource_group_name = var.resource_group_name
  location            = var.location
  allocation_method   = "Static"
  sku                 = "Standard"
  tags                = var.tags
}

resource "azurerm_lb" "this" {
  name                = "${var.name_prefix}-lb"
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = "Standard"
  tags                = var.tags

  frontend_ip_configuration {
    name                 = "PublicIPAddress"
    public_ip_address_id = azurerm_public_ip.this.id
  }
}

resource "azurerm_lb_backend_address_pool" "this" {
  name            = "${var.name_prefix}-lb-backend-pool"
  loadbalancer_id = azurerm_lb.this.id
}

resource "azurerm_lb_probe" "this" {
  name                = "${var.name_prefix}-lb-probe"
  loadbalancer_id     = azurerm_lb.this.id
  protocol            = "Tcp"
  port                = var.backend_port
  interval_in_seconds = 30
  number_of_probes    = 2
}

resource "azurerm_lb_rule" "this" {
  name                           = "${var.name_prefix}-lb-rule"
  loadbalancer_id                = azurerm_lb.this.id
  protocol                       = "Tcp"
  frontend_port                  = var.frontend_port
  backend_port                   = var.backend_port
  frontend_ip_configuration_name = "PublicIPAddress"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.this.id]
  probe_id                       = azurerm_lb_probe.this.id
}

resource "azurerm_network_interface_backend_address_pool_association" "this" {
  for_each = var.nic_ids

  network_interface_id    = each.value
  ip_configuration_name   = var.nic_ip_configuration_names[each.key]
  backend_address_pool_id = azurerm_lb_backend_address_pool.this.id
}

output "public_ip_address" {
  description = "Public IP address assigned to the load balancer."
  value       = azurerm_public_ip.this.ip_address
}

output "load_balancer_id" {
  description = "Azure Load Balancer resource ID."
  value       = azurerm_lb.this.id
}

output "backend_pool_id" {
  description = "Backend address pool ID."
  value       = azurerm_lb_backend_address_pool.this.id
}

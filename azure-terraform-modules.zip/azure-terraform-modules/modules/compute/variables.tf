variable "name_prefix" {
  type        = string
  description = "Prefix used for resource names."
}

variable "resource_group_name" {
  type        = string
  description = "Existing resource group name from networking module."
}

variable "location" {
  type        = string
  description = "Azure region."
}

variable "subnet_id" {
  type        = string
  description = "Subnet ID where NICs will be created."
}

variable "instance" {
  description = "Map of VM names to size and Availability Zone."
  type = map(object({
    size              = string
    availability_zone = string
  }))
}

variable "admin_username" {
  type        = string
  description = "Linux administrator username."
}

variable "ssh_public_key_path" {
  type        = string
  description = "Local path to the SSH public key."
}

variable "tags" {
  type        = map(string)
  description = "Tags to apply to resources."
}

resource "azurerm_network_interface" "this" {
  for_each = var.instance

  name                = "${var.name_prefix}-${each.key}-nic"
  location            = var.location
  resource_group_name = var.resource_group_name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }

  tags = merge(var.tags, { Instance = each.key })
}

resource "azurerm_linux_virtual_machine" "this" {
  for_each = var.instance

  name                = "${var.name_prefix}-${each.key}-linuxvm"
  location            = var.location
  resource_group_name = var.resource_group_name
  size                = each.value.size
  zone                = each.value.availability_zone
  admin_username      = var.admin_username

  network_interface_ids = [
    azurerm_network_interface.this[each.key].id
  ]

  admin_ssh_key {
    username   = var.admin_username
    public_key = file(pathexpand(var.ssh_public_key_path))
  }

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts"
    version   = "latest"
  }

  custom_data = base64encode(<<-CLOUD_CONFIG
    #cloud-config
    package_update: true
    packages:
      - nginx
    runcmd:
      - systemctl enable nginx
      - systemctl restart nginx
      - bash -c 'echo "Hello from ${var.name_prefix}-${each.key}" > /var/www/html/index.html'
  CLOUD_CONFIG
  )

  tags = merge(var.tags, { Instance = each.key })
}

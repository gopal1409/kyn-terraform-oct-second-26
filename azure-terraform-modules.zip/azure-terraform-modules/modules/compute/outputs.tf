output "nic_ids" {
  description = "NIC IDs keyed by VM instance key."
  value       = { for key, nic in azurerm_network_interface.this : key => nic.id }
}

output "nic_ip_configuration_names" {
  description = "NIC IP configuration names keyed by VM instance key."
  value       = { for key, nic in azurerm_network_interface.this : key => nic.ip_configuration[0].name }
}

output "vm_details" {
  description = "VM details keyed by instance name."
  value = {
    for key, vm in azurerm_linux_virtual_machine.this : key => {
      vm_id      = vm.id
      vm_name    = vm.name
      vm_size    = vm.size
      zone       = vm.zone
      private_ip = azurerm_network_interface.this[key].private_ip_address
      nic_id     = azurerm_network_interface.this[key].id
    }
  }
}

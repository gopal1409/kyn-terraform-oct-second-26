terraform {
  backend "azurerm" {
    resource_group_name  = "gopal-storage-acc"
    storage_account_name = "gopalstorageacc"
    container_name       = "tfstate"
    key                  = "sap-dev.tfstate"
    use_azuread_auth     = true
  }
}

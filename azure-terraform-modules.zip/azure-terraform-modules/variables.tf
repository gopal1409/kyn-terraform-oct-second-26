variable "project_name" {
  description = "Project name used as a resource name prefix."
  type        = string
  default     = "sap"
}

variable "environment" {
  description = "Deployment environment."
  type        = string
}

variable "resource_group_name" {
  description = "Suffix used in the resource group name."
  type        = string
  default     = "gopal_rg"
}

variable "location" {
  description = "Azure region."
  type        = string
  default     = "eastus"
}

variable "vnet_name" {
  description = "Virtual network name suffix."
  type        = string
  default     = "gopal-network"
}

variable "vnet_address_space" {
  description = "Virtual network CIDR ranges."
  type        = list(string)
  default     = ["10.0.0.0/16"]
}

variable "subnet_name" {
  description = "Subnet name suffix."
  type        = string
  default     = "web-subnet"
}

variable "subnet_address_prefixes" {
  description = "Subnet CIDR ranges."
  type        = list(string)
  default     = ["10.0.1.0/24"]
}

variable "instance" {
  description = "Map of VM names to size and Availability Zone."
  type = map(object({
    size              = string
    availability_zone = string
  }))
}

variable "ssh_public_key_path" {
  description = "Path to the SSH public key file on the workstation running Terraform."
  type        = string
  default     = "~/.ssh/id_rsa.pub"
}

variable "ssh_source_address_prefix" {
  description = "Trusted source CIDR for SSH, e.g. 203.0.113.10/32. Replace before deployment."
  type        = string
  default     = "0.0.0.0/0"
}

variable "admin_username" {
  description = "Linux VM administrator username."
  type        = string
  default     = "azureuser"
}

variable "lb_frontend_port" {
  description = "Load balancer frontend TCP port."
  type        = number
  default     = 80
}

variable "lb_backend_port" {
  description = "Backend VM TCP port."
  type        = number
  default     = 80
}
